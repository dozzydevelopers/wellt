import express, { type Express, type Request, type Response } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import http from "http";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);

// ── PHP Portal Proxy ──────────────────────────────────────────────────────────
// Strips /portal prefix, proxies to PHP built-in server, rewrites all
// absolute paths in response bodies and Location headers back to /portal/...
const PHP_PORT = parseInt(process.env["PHP_PORT"] ?? "8082", 10);
const PORTAL_PREFIX = "/portal";

function rewriteBody(html: string): string {
  return html
    // Double-quoted href/action/src — .php paths
    .replace(/(href|action|src)="(\/(?!portal)[^"]*\.php[^"]*)"/g, `$1="/portal$2"`)
    // Single-quoted href/action/src — .php paths
    .replace(/(href|action|src)='(\/(?!portal)[^']*\.php[^']*)'/g, `$1='/portal$2'`)
    // Asset directories (double + single quotes)
    .replace(/(href|action|src)="(\/(?:assets|uploads|storage)\/[^"]*)"/g, `$1="/portal$2"`)
    .replace(/(href|action|src)='(\/(?:assets|uploads|storage)\/[^']*)'/g, `$1='/portal$2'`)
    // JS redirects: window.location, location.href, location.replace
    .replace(/(window\.location|location\.href|location\.replace)\s*=\s*"(\/(?!portal)[^"]+)"/g, `$1="/portal$2"`)
    .replace(/(window\.location|location\.href|location\.replace)\s*=\s*'(\/(?!portal)[^']+)'/g, `$1='/portal$2'`)
    // header('Location: ...') patterns reflected in HTML meta refreshes
    .replace(/(content=["']0;url=)(\/(?!portal)[^"']+)(["'])/g, `$1/portal$2$3`)
    // Absolute localhost URLs → strip host, prepend /portal
    .replace(/https?:\/\/[^/'"]+\/(assets\/[^"'\s]*)/g, '/portal/$1')
    .replace(/https?:\/\/[^/'"]+\/(uploads\/[^"'\s]*)/g, '/portal/$1')
    // Keep bare /public and /admin non-.php links (rare but guard)
    .replace(/(href|action)="(\/(?:public|admin)\/(?!portal)[^".]*)"/g, `$1="/portal$2"`);
}

// app.use strips the mount prefix from req.url automatically in Express
app.use(PORTAL_PREFIX, (req: Request, res: Response) => {
  const phpPath = req.url || "/";

  // Forward cookies and relevant headers to PHP
  const phpHeaders: Record<string, string | string[]> = {
    host: `localhost:${PHP_PORT}`,
    cookie: (req.headers["cookie"] as string) ?? "",
    "content-type": (req.headers["content-type"] as string) ?? "",
    "content-length": (req.headers["content-length"] as string) ?? "",
    "user-agent": (req.headers["user-agent"] as string) ?? "",
    accept: (req.headers["accept"] as string) ?? "*/*",
    "accept-language": (req.headers["accept-language"] as string) ?? "",
    "x-forwarded-for": req.ip ?? "",
  };

  // Build body for POST requests
  let body = "";
  if (req.method === "POST" && req.body) {
    const qs = new URLSearchParams(req.body as Record<string, string>).toString();
    body = qs;
    phpHeaders["content-type"] = "application/x-www-form-urlencoded";
    phpHeaders["content-length"] = Buffer.byteLength(body).toString();
  }

  const opts: http.RequestOptions = {
    hostname: "localhost",
    port: PHP_PORT,
    path: phpPath,
    method: req.method,
    headers: phpHeaders,
  };

  const phpReq = http.request(opts, (phpRes) => {
    // Rewrite Location redirect header
    let location = phpRes.headers["location"] ?? "";
    if (location && typeof location === "string") {
      if (!location.startsWith(PORTAL_PREFIX) && !location.startsWith("http")) {
        location = PORTAL_PREFIX + (location.startsWith("/") ? location : "/" + location);
      }
      phpRes.headers["location"] = location;
    }

    // Pass cookies through
    const setCookie = phpRes.headers["set-cookie"];

    // Collect response body
    const chunks: Buffer[] = [];
    phpRes.on("data", (chunk: Buffer) => chunks.push(chunk));
    phpRes.on("end", () => {
      const rawBody = Buffer.concat(chunks);
      const contentType = phpRes.headers["content-type"] ?? "";
      const isHtml = contentType.includes("text/html") || contentType.includes("text/plain");

      let finalBody: Buffer;
      if (isHtml) {
        const rewritten = rewriteBody(rawBody.toString("utf8"));
        finalBody = Buffer.from(rewritten, "utf8");
      } else {
        finalBody = rawBody;
      }

      res.status(phpRes.statusCode ?? 200);

      // Forward headers (skip content-length since body size may change)
      for (const [key, val] of Object.entries(phpRes.headers)) {
        if (key === "content-length" || key === "transfer-encoding") continue;
        if (key === "set-cookie" && Array.isArray(val)) {
          val.forEach((v) => res.append("set-cookie", v));
        } else if (val !== undefined) {
          res.setHeader(key, val as string | string[]);
        }
      }

      res.end(finalBody);
    });
  });

  phpReq.on("error", () => {
    res.status(502).send(`
      <html><head><title>Portal Starting</title>
      <meta http-equiv="refresh" content="5"></head>
      <body style="font-family:sans-serif;text-align:center;padding:80px;background:#010c1f;color:#fff">
        <h2 style="color:#c9a227">&#9656; Investor Portal starting…</h2>
        <p style="color:rgba(255,255,255,0.5)">Initialising PHP backend — refreshing in 5 seconds.</p>
      </body></html>
    `);
  });

  if (body) phpReq.write(body);
  phpReq.end();
});

export default app;
