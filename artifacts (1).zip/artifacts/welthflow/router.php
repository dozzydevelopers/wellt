<?php
$uri = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

$publicDir = __DIR__ . '/public';
$spaDir = $publicDir . '/frontend';
$spaIndex = $spaDir . '/index.html';

// If the requested file exists inside the public directory, let the built-in server serve it directly.
$file = $publicDir . $uri;
if (file_exists($file) && !is_dir($file)) {
    return false;
}

// If the request is for the root path, serve the SPA if available; otherwise keep the original PHP login behavior.
if ($uri === '/' || $uri === '') {
    if (file_exists($spaIndex)) {
        header('Content-Type: text/html; charset=utf-8');
        readfile($spaIndex);
        exit;
    }
    header('Location: /public/login.php');
    exit;
}

// If the request is for the frontend route or any missing route, serve the SPA if it exists.
if (file_exists($spaIndex)) {
    header('Content-Type: text/html; charset=utf-8');
    readfile($spaIndex);
    exit;
}

// Otherwise return a simple 404.
http_response_code(404);
echo '<!DOCTYPE html><html><head><title>404</title></head><body style="font-family:sans-serif;text-align:center;padding:60px"><h1>404 Not Found</h1><p><a href="/public/login.php">Go to Login</a></p></body></html>';
